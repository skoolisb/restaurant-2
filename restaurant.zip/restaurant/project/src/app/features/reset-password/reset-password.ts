import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  styleUrl: './reset-password.css',
  templateUrl: './reset-password.html',
})
export class ResetPassword {
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);

  isSubmitting = false;
  successMessage = '';
  errorMessage = '';

  form = this.fb.nonNullable.group({
    token: [this.route.snapshot.queryParamMap.get('token') ?? '', [Validators.required]],
    newPassword: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]],
  });

  get passwordMismatch(): boolean {
    const { newPassword, confirmPassword } = this.form.getRawValue();
    return !!newPassword && !!confirmPassword && newPassword !== confirmPassword;
  }

  resetPassword(): void {
    this.form.markAllAsTouched();
    this.successMessage = '';
    this.errorMessage = '';

    if (this.form.invalid || this.passwordMismatch) {
      this.errorMessage = 'Please provide a valid reset token and matching passwords.';
      return;
    }

    this.isSubmitting = true;

    const { confirmPassword, ...payload } = this.form.getRawValue();

    this.authService.resetPassword(payload).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.successMessage = 'Password reset successfully.';
        this.form.reset({ token: this.route.snapshot.queryParamMap.get('token') ?? '' });
      },
      error: (error: HttpErrorResponse) => {
        this.isSubmitting = false;
        this.errorMessage = error.error?.message || 'Password reset failed. Please try again.';
      },
    });
  }
}
