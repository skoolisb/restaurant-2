import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { Product, ProductService } from '../../services/product.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  styleUrl: './home.css',
  templateUrl: './home.html',
})
export class Home implements OnInit {
  private readonly productService = inject(ProductService);

  products: Product[] = this.productService.getFallbackProducts();
  isLoading = false;

  ngOnInit(): void {
    this.loadProducts();
  }

  private loadProducts(): void {
    this.isLoading = true;

    this.productService.getProducts().subscribe({
      next: (products) => {
        this.products = products;
      },
      error: () => {
        this.products = this.productService.getFallbackProducts();
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }
}
