import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-favourites',
  styleUrl: './favourites.css',
  templateUrl: './favourites.html',
})
export class Favourites {
}
