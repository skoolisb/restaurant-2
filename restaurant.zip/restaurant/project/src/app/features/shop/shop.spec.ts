import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Shop } from './shop';

describe('Shop', () => {
  let component: Shop;
  let fixture: ComponentFixture<Shop>;
  let httpTestingController: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Shop, HttpClientTestingModule],
    }).compileComponents();

    fixture = TestBed.createComponent(Shop);
    component = fixture.componentInstance;
    httpTestingController = TestBed.inject(HttpTestingController);
    await fixture.whenStable();
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load fallback products when the product API returns an error', () => {
    const req = httpTestingController.expectOne(
      'https://restaurantapi.stepacademy.ge/api/products',
    );
    req.flush(null, { status: 500, statusText: 'Server Error' });

    expect(component.products.length).toBeGreaterThan(0);
    expect(component.errorMessage).toContain('Failed to load products');
  });
});
