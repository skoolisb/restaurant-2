import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { Product, ProductService } from '../../services/product.service';

@Component({
  selector: 'app-shop',
  standalone: true,
  imports: [CommonModule],
  styleUrl: './shop.css',
  templateUrl: './shop.html',
})
export class Shop implements OnInit {
  private readonly productService = inject(ProductService);

  products: Product[] = this.productService.getFallbackProducts();
  isLoading = false;
  errorMessage = '';

  ngOnInit(): void {
    this.loadProducts();
  }

  private loadProducts(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.productService.getProducts().subscribe({
      next: (products) => {
        this.products = products;
      },
      error: () => {
        this.products = this.productService.getFallbackProducts();
        this.errorMessage = 'Failed to load products. Showing sample menu.';
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }
}
