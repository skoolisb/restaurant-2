import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-qrcode',
  styleUrl: './qrcode.css',
  templateUrl: './qrcode.html',
})
export class Qrcode {
}
