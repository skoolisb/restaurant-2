import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  styleUrl: './register.css',
  templateUrl: './register.html',
})
export class Register {
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);

  isSubmitting = false;
  successMessage = '';
  errorMessage = '';

  form = this.fb.nonNullable.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern(/^\+?[0-9\s-]{7,}$/)]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', Validators.required],
  });

  get passwordMismatch(): boolean {
    const { password, confirmPassword } = this.form.getRawValue();
    return !!password && !!confirmPassword && password !== confirmPassword;
  }

  register(): void {
    this.form.markAllAsTouched();
    this.successMessage = '';
    this.errorMessage = '';

    if (this.form.invalid || this.passwordMismatch) {
      this.errorMessage = 'Please fill in all fields correctly and make sure passwords match.';
      return;
    }

    this.isSubmitting = true;

    const { confirmPassword, ...payload } = this.form.getRawValue();

    this.authService.register(payload).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.successMessage = 'Registration successful!';
        this.form.reset();
        this.refreshAccessToken();
      },
      error: (error: HttpErrorResponse) => {
        this.isSubmitting = false;
        this.errorMessage = error.error?.message || 'Registration failed. Please try again.';
      },
    });
  }

  private refreshAccessToken(): void {
    this.authService.refreshAccessToken().subscribe({
      next: (response) => {
        console.log('Refresh access token response:', response);
      },
      error: (error: HttpErrorResponse) => {
        console.error('Refresh access token failed:', error);
      },
    });
  }
}
