import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = 'https://restaurantapi.stepacademy.ge/api/auth';
  private readonly refreshAccessTokenUrl =
    'https://restaurantapi.stepacademy.ge/api/auth/refresh-access-token/1a260350-5cda-4c3f-9027-d3f9f185fa55';

  login(payload: { email: string; password: string }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/login`, payload);
  }

  register(payload: Record<string, unknown>): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, payload);
  }

  refreshAccessToken(): Observable<any> {
    return this.http.get(this.refreshAccessTokenUrl);
  }

  resetPassword(payload: Record<string, unknown>): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/reset-password`, payload);
  }

  verifyEmail(payload: Record<string, unknown>): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/verify-email`, payload);
  }
}
