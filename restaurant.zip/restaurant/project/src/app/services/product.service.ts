import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface Product {
  id: number;
  name?: string;
  title?: string;
  productName?: string;
  description: string;
  price: number;
  rating: number;
  image: string;
}

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = 'https://restaurantapi.stepacademy.ge/api/products';

  getProducts(): Observable<Product[]> {
    return this.http.get<any>(this.apiUrl).pipe(
      map((response) => this.normalizeProducts(response)),
      catchError(() => of(this.getFallbackProducts())),
    );
  }

  getFallbackProducts(): Product[] {
    return [
      {
        id: 1,
        name: 'Sfogiatelle',
        description: 'Flaky, shell-shaped pasties filled with sweet ricotta and candied citrus.',
        price: 8,
        rating: 2.7,
        image:
          'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 2,
        name: 'Affogato',
        description: 'Vanilla gelato “drowned” in hot espresso.',
        price: 6.5,
        rating: 3.9,
        image:
          'https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 3,
        name: 'Cassata Siciliana',
        description:
          'Elaborate Sicilian cake with ricotta, marzipan, candied fruit, and decorative icing.',
        price: 11,
        rating: 5,
        image:
          'https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=900&q=80',
      },
    ];
  }

  normalizeProducts(response: any): Product[] {
    const data = Array.isArray(response) ? response : (response?.data ?? response?.products ?? []);

    if (!Array.isArray(data) || !data.length) {
      return this.getFallbackProducts();
    }

    return data.slice(0, 3).map((item, index) => ({
      id: Number(item.id ?? index + 1),
      name: item.name ?? item.title ?? item.productName ?? `Dish ${index + 1}`,
      description:
        item.description ??
        item.summary ??
        'Freshly prepared using the finest ingredients and time-honored recipes.',
      price: Number(item.price ?? item.amount ?? 0),
      rating: Number(item.rating ?? item.score ?? 4.5),
      image:
        item.image ??
        item.img ??
        item.photo ??
        this.getFallbackProducts()[index % this.getFallbackProducts().length]?.image ??
        'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=80',
    }));
  }
}
